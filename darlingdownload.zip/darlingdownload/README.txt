GUIDA ALL' UTILIZZO DI DARLING

Svolgere i seguenti passaggi per avere un ottima e semplice installazione e comprensione dell'interfaccia.

1. Una volta scaricato il programma, estrarre il contenuto della cartella zippata (.zip) e salvarlo dove preferite;

2. Avviare il file "darlingos.exe", qui, è possibile utilizzare Darling a pieno:

	2.1 ATTENZIONE! NON CHIUDERE IL PROGRAMMA SENZA L'OPPORTUNO COMANDO

	2.2 Nella prima linea, si notano ora locale e percentuale della batteria del dispositivo; nella linea sottostante, vanno inseriti i vari comandi.

	2.3 Mediante il comando "darling.", con l'aggiunta di alcuni "comandi", possiamo avviare e utilizzare diversi programmi
	    
	    LISTA ATTRIBUTI:

		2.2.1	'.execute'	=> Permette di eseguire i file (.exe)
		2.2.2	'.calendar'	=> Mostra a schermo il calendario
		2.2.3	'.delete'	=> Elimina qualsiasi tipo di file
		2.2.4	'.newpsw'	=> Permette di reimpostare la password di accesso
		2.2.5	'.convert'	=> Permette di convertire un file
		2.2.6	'.newfolder'	=> Permette di creare una nuova cartella
		2.2.7	'.newfile'	=> Permette di creare un nuovo file
		2.2.8	'.deletec'	=> Permette di resettare la cache (appunti)
		2.2.9	'.extract'	=> Permette di estrarre un file compresso (.zip)
		2.2.10	'.showf'	=> Mostra i file di una cartella specifica
		2.2.11	'.format'	=> Formatta l'intero sistema
		2.2.12	'.show'		=> Mostra i file presenti nel desktop
		2.2.13	'.move'		=> Permette di spostare un file in un altra directory (cartella)
		2.2.14	'.renamefolder'	=> Permette di rinominare una cartella
		2.2.15	'.renamefile'	=> Permette di rinominare un file
		2.2.16	'.write'	=> Permette di modificare un file
		2.2.17	'.zip'		=> Permette di comprimere un file
		2.2.18	'.clear'	=> Permette di pulire il terminale
		2.2.19	'.showc'	=> Mostra il contenuto della cache
		2.2.20	'.copy'		=> Permette di copiare il contenuto di un file nella cache (utilizzabile solo col comando '.write')
		2.2.21	'.paste'	=> Permette di incollare il contenuto di un file dalle cache (utilizzabile solo col comando '.write')
		2.2.22	'.close'	=> Permette di terminare l'esecuzione di un operazione (da utilizzare al primo input)
		2.2.23	'.shutdown'	=> Termina l'esecuzione del sistema operativo
		2.2.24	'.info'		=> Mostra le informazioni generali
		2.2.25	'.chlg'		=> Permette di cambiare la lingua del sistema operativo
		

3. DARLIING STORE: Le funzioni preseti nello store, vanno scaricare e poi per essere eseguite, vanno messe nella stessa cartella dove è presente il file "nome del file" e poi tramite il comando 'darling.execute' e i successivi passaggi, possono essere avviate e utilizzate.

GRAZIE PER AVER SCARICATO DARLING!





